# Competition Bot · 直接上传最新包

仓库根目录的 **`CoreGeek.tar.gz`** 就是最新可上传产物。下载后直接交给比赛平台，无需编译、安装依赖或重新打包。仓库只保留这一份包，更新时覆盖同名文件。

## 平台解压与启动

压缩包包含顶层 `CoreGeek/`，解压到 `/home/docker` 后，入口必须是：

```text
/home/docker/CoreGeek/main3.py
/home/docker/CoreGeek/src/agent/...
```

平台继续使用原来的启动方式即可：

```bash
python3 /home/docker/CoreGeek/main3.py 8080
```

`8080` 替换为平台指定端口。也支持 `bash /home/docker/CoreGeek/run.sh 8080`。程序监听 `0.0.0.0:<port>`，通过 HTTP 接收游戏状态并返回动作；保持前台运行。

接收者不需要搭建编译环境。程序使用比赛平台已有的 Python，最低要求为 3.11；包内不包含 Python 解释器，不需要第三方 Python 库、GPU、模型下载或 API Key。平台 Python 具体版本仍待确认。本机已验证解压后的直接入口和 Bash 入口，以及默认、试验两种策略的 HTTP 请求。

## 可选：连通性检查

服务启动后，在 `CoreGeek` 目录运行：

```bash
curl -sS -H 'Content-Type: application/json' \
  --data-binary @sample-request.json http://127.0.0.1:8080/
```

应返回包含 `roleCommandMap` 的动作 JSON。比赛平台负责连续提供状态和结算动作。

## 可选：范围攻击试验策略

默认是最近目标策略；试验范围策略需要显式启用：

```bash
COMPETITION_ROCKET_POLICY=/home/docker/CoreGeek/selected-policy.json \
  python3 /home/docker/CoreGeek/main3.py 8080
```

试验策略在合成场景中清怪更多、基地损伤也更多，尚未替换默认策略。停止服务、取消该环境变量并使用普通命令即可恢复默认。

## 包内内容

`main3.py`、`src/agent/` 和 `run.sh` 是运行入口与算法；`selected-policy.json` 是可选策略配置；`sample-request.json` 是请求样例；`MANIFEST.json` 记录各文件的 SHA-256。`pyproject.toml` 仅说明 Python 版本，直接启动不需要安装项目。

该版本主要包含基础采集建设和夜间防守。新闻、宝藏、自进化任务解题尚未实现；正式比赛成绩尚未验证。
